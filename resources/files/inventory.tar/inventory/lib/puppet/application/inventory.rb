require 'puppet/application/face_base'

class Puppet::Application::Inventory < Puppet::Application::FaceBase
end
